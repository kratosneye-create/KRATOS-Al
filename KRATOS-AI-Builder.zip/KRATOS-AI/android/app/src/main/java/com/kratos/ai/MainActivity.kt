package com.kratos.ai

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import android.widget.TextView
import android.graphics.Color as AndroidColor
import android.text.method.LinkMovementMethod
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.launch

private val Night = Color(0xFF070B16)
private val Panel = Color(0xFF101A2D)
private val Panel2 = Color(0xFF14223A)
private val Electric = Color(0xFF268BFF)
private val SoftText = Color(0xFF9EABC2)
private val White = Color(0xFFF2F6FF)

data class ChatMessage(
    val id: Long = System.nanoTime(),
    val role: String,
    val content: String,
    val imageDataUrl: String? = null
)
data class ChatThread(val id: Long, val title: String, val messages: List<ChatMessage>)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(7, 11, 22)
        window.navigationBarColor = android.graphics.Color.rgb(7, 11, 22)
        setContent { KratosApp() }
    }
}

@Composable
fun KratosApp() {
    val context = LocalContext.current
    val store = remember { context.getSharedPreferences("kratos_local", 0) }
    val gson = remember { Gson() }
    val type = remember { object : TypeToken<List<ChatThread>>() {}.type }
    var threads by remember {
        mutableStateOf(
            runCatching { gson.fromJson<List<ChatThread>>(store.getString("threads", "[]"), type) ?: emptyList() }
                .getOrDefault(emptyList())
                .ifEmpty { listOf(ChatThread(System.currentTimeMillis(), "New conversation", emptyList())) }
        )
    }
    var activeId by remember { mutableLongStateOf(threads.first().id) }
    var draft by remember { mutableStateOf("") }
    var pendingImage by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val api = remember { KratosApi() }
    val listState = rememberLazyListState()

    fun persist() { store.edit().putString("threads", gson.toJson(threads)).apply() }
    fun newChat() {
        val id = System.currentTimeMillis()
        threads = listOf(ChatThread(id, "New conversation", emptyList())) + threads
        activeId = id
        persist()
        draft = ""
        pendingImage = null
    }
    val active = threads.firstOrNull { it.id == activeId } ?: threads.firstOrNull()
    val messages = active?.messages ?: emptyList()

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                if (bytes != null && bytes.size <= 4_000_000) {
                    val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
                    pendingImage = "data:$mime;base64," + android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
                }
            }
        }
    }
    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) draft = (draft + " " + spoken).trim()
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Night, surface = Panel, primary = Electric, onPrimary = White,
        onBackground = White, onSurface = White, secondary = Color(0xFF71B7FF)
    )) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0C1730), Night, Night)))) {
            Column(Modifier.fillMaxSize()) {
                TopBar(
                    onNew = { newChat() },
                    onHistory = { showHistory = !showHistory }
                )
                if (showHistory) {
                    HistoryPanel(
                        threads = threads,
                        selected = activeId,
                        onSelect = { activeId = it; showHistory = false },
                        onClose = { showHistory = false }
                    )
                } else {
                    if (messages.isEmpty()) {
                        WelcomePanel(onPrompt = { draft = it })
                    }
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(messages, key = { it.id }) { message ->
                            MessageBubble(message)
                        }
                        if (busy) item { ThinkingIndicator() }
                    }
                    if (pendingImage != null) {
                        Row(Modifier.padding(horizontal = 18.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Image attached", color = Color(0xFF8FC4FF), fontSize = 12.sp)
                            IconButton(onClick = { pendingImage = null }) { Icon(Icons.Default.Close, null, tint = SoftText) }
                        }
                    }
                    Composer(
                        value = draft,
                        onValue = { draft = it },
                        onAttach = { imagePicker.launch("image/*") },
                        onVoice = {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to KRATOS")
                            }
                            runCatching { voiceLauncher.launch(intent) }
                        },
                        onSend = {
                            if (draft.isNotBlank() || pendingImage != null) {
                                val userText = draft.ifBlank { "Please analyze this image." }
                                val userMessage = ChatMessage(role = "user", content = userText, imageDataUrl = pendingImage)
                                val updated = messages + userMessage
                                val savedMessages = messages + userMessage.copy(imageDataUrl = null)
                                val title = if (messages.isEmpty()) userText.take(34) else (active?.title ?: "Conversation")
                                threads = threads.map { if (it.id == activeId) it.copy(title = title, messages = savedMessages) else it }
                                persist()
                                draft = ""
                                val imageForRequest = pendingImage
                                pendingImage = null
                                busy = true
                                scope.launch {
                                    try {
                                        val reply = api.send(updated)
                                        val current = threads.firstOrNull { it.id == activeId }
                                        if (current != null) {
                                            threads = threads.map { if (it.id == activeId) it.copy(messages = it.messages + ChatMessage(role = "assistant", content = reply)) else it }
                                            persist()
                                        }
                                    } catch (e: Exception) {
                                        threads = threads.map { if (it.id == activeId) it.copy(messages = it.messages + ChatMessage(role = "assistant", content = "I couldn't reach the KRATOS server. Check your connection and backend URL, then try again.\\n\\n_${e.message ?: "Network error"}_")) else it }
                                        persist()
                                    } finally { busy = false }
                                }
                            }
                        },
                        enabled = !busy
                    )
                }
                Text("KRATOS AI  •  THINK BEYOND", color = Color(0xFF52627C), fontSize = 9.sp, letterSpacing = 2.sp,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
fun TopBar(onNew: () -> Unit, onHistory: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BrainMark(Modifier.size(42.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("KRATOS", fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp, color = White)
            Text("INTELLIGENCE, UNLEASHED", fontSize = 8.sp, letterSpacing = 1.8.sp, color = Electric)
        }
        IconButton(onClick = onHistory) { Icon(Icons.Default.History, "Chat history", tint = SoftText) }
        IconButton(onClick = onNew, modifier = Modifier.clip(CircleShape).background(Panel2)) {
            Icon(Icons.Default.Add, "New chat", tint = Electric)
        }
    }
}

@Composable
fun BrainMark(modifier: Modifier = Modifier) {
    androidx.compose.foundation.Canvas(modifier) {
        val w = size.width; val h = size.height
        drawCircle(Brush.radialGradient(listOf(Color(0xFF1B5BB4), Color(0xFF0B1930))), radius = size.minDimension / 2)
        val p = androidx.compose.ui.graphics.Path().apply {
            moveTo(w*.5f,h*.19f); cubicTo(w*.25f,h*.08f,w*.16f,h*.34f,w*.29f,h*.48f)
            cubicTo(w*.14f,h*.69f,w*.34f,h*.87f,w*.49f,h*.76f)
            moveTo(w*.5f,h*.19f); cubicTo(w*.75f,h*.08f,w*.84f,h*.34f,w*.71f,h*.48f)
            cubicTo(w*.86f,h*.69f,w*.66f,h*.87f,w*.51f,h*.76f)
            moveTo(w*.5f,h*.2f); lineTo(w*.5f,h*.78f)
        }
        drawPath(p, Color(0xFF8CCBFF), style = androidx.compose.ui.graphics.drawscope.Stroke(width = w*.045f, cap = androidx.compose.ui.graphics.StrokeCap.Round))
        for (i in 0..2) {
            drawCircle(Color(0xFFB8E2FF), radius = w*.035f, center = androidx.compose.ui.geometry.Offset(w*(.34f+i*.16f), h*(.4f+(i%2)*.18f)))
        }
    }
}

@Composable
fun WelcomePanel(onPrompt: (String) -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        BrainMark(Modifier.size(92.dp))
        Spacer(Modifier.height(18.dp))
        Text("YOUR MIND. AMPLIFIED.", color = White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text("Ask anything. Solve the impossible.\nBuild what comes next.", color = SoftText, textAlign = TextAlign.Center, lineHeight = 22.sp)
        Spacer(Modifier.height(26.dp))
        val prompts = listOf("Solve a maths problem step by step", "Explain a difficult school topic", "Help me understand an image")
        prompts.forEach { prompt ->
            Row(
                Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(14.dp))
                    .background(Panel).clickable { onPrompt(prompt) }.padding(15.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(prompt, Modifier.weight(1f), color = Color(0xFFD7E5FA), fontSize = 13.sp)
                Icon(Icons.Default.ArrowUpward, null, tint = Electric, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun MessageBubble(message: ChatMessage) {
    val isUser = message.role == "user"
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (isUser) Alignment.End else Alignment.Start) {
        Text(if (isUser) "YOU" else "KRATOS", color = if (isUser) Color(0xFF7EA7D8) else Electric,
            fontSize = 9.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp))
        Column(
            Modifier.widthIn(max = 330.dp).clip(RoundedCornerShape(18.dp))
                .background(if (isUser) Color(0xFF12366A) else Panel)
                .padding(horizontal = 15.dp, vertical = 12.dp)
        ) {
            if (message.imageDataUrl != null) Text("📎 Image attached", color = Color(0xFFB8D9FF), fontSize = 11.sp)
            if (isUser) Text(message.content, color = White, fontSize = 14.sp, lineHeight = 21.sp)
            else AndroidView(
                factory = { ctx -> TextView(ctx).apply {
                    setTextColor(AndroidColor.rgb(229, 237, 250))
                    textSize = 14f
                    setLineSpacing(3f, 1.05f)
                    movementMethod = LinkMovementMethod.getInstance()
                } },
                update = { view ->
                    val markwon = io.noties.markwon.Markwon.create(view.context)
                    markwon.setMarkdown(view, message.content)
                }
            )
        }
    }
}

@Composable
fun ThinkingIndicator() {
    Row(Modifier.clip(RoundedCornerShape(16.dp)).background(Panel).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(Modifier.size(15.dp), color = Electric, strokeWidth = 2.dp)
        Spacer(Modifier.width(10.dp))
        Text("KRATOS is thinking…", color = SoftText, fontSize = 12.sp)
    }
}

@Composable
fun Composer(value: String, onValue: (String) -> Unit, onAttach: () -> Unit, onVoice: () -> Unit, onSend: () -> Unit, enabled: Boolean) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)
            .clip(RoundedCornerShape(24.dp)).background(Panel2).padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onAttach, enabled = enabled) { Icon(Icons.Default.AttachFile, "Attach image", tint = SoftText) }
        BasicTextField(
            value = value, onValueChange = onValue, enabled = enabled,
            modifier = Modifier.weight(1f).padding(horizontal = 6.dp),
            textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 14.sp),
            cursorBrush = Brush.linearGradient(listOf(Electric, Color.Cyan)),
            keyboardOptions = KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { onSend() }),
            decorationBox = { inner ->
                Box {
                    if (value.isEmpty()) Text("Message KRATOS…", color = Color(0xFF72839E), fontSize = 14.sp)
                    inner()
                }
            }
        )
        IconButton(onClick = onVoice, enabled = enabled) { Icon(Icons.Default.Mic, "Voice input", tint = SoftText) }
        IconButton(onClick = onSend, enabled = enabled && value.isNotBlank()) {
            Icon(Icons.Default.Send, "Send", tint = if (value.isNotBlank()) Electric else SoftText)
        }
    }
}

@Composable
fun HistoryPanel(threads: List<ChatThread>, selected: Long, onSelect: (Long) -> Unit, onClose: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(18.dp)).background(Panel).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("YOUR CONVERSATIONS", Modifier.weight(1f), color = Electric, fontSize = 10.sp, letterSpacing = 1.5.sp)
            IconButton(onClick = onClose) { Icon(Icons.Default.Close, null, tint = SoftText) }
        }
        if (threads.isEmpty()) Text("No saved conversations yet.", color = SoftText, fontSize = 13.sp)
        threads.take(20).forEach { thread ->
            Text(
                thread.title.ifBlank { "New conversation" },
                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                    .background(if (thread.id == selected) Panel2 else Color.Transparent)
                    .clickable { onSelect(thread.id) }.padding(12.dp),
                color = White, fontSize = 13.sp, maxLines = 1
            )
        }
    }
}
