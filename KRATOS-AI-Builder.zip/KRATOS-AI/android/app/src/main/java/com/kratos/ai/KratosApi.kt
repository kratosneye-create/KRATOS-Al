package com.kratos.ai

import com.google.gson.Gson
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

class KratosApi {
    private val gson = Gson()
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    fun send(messages: List<ChatMessage>): String {
        val payloadMessages = messages.takeLast(24).map {
            mapOf(
                "role" to it.role,
                "content" to it.content,
                "imageDataUrl" to it.imageDataUrl
            ).filterValues { value -> value != null }
        }
        val json = gson.toJson(mapOf("messages" to payloadMessages))
        val body = json.toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url(BuildConfig.KRATOS_API_BASE_URL + "v1/chat")
            .post(body)
            .build()

        client.newCall(request).execute().use { response ->
            val responseText = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val error = runCatching { gson.fromJson(responseText, Map::class.java)["error"] as? String }.getOrNull()
                throw IllegalStateException(error ?: "Server error ${response.code}")
            }
            val result = gson.fromJson(responseText, Map::class.java)
            return result["reply"] as? String ?: throw IllegalStateException("Invalid server response")
        }
    }
}
