import "dotenv/config";
import express from "express";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";
import { z } from "zod";

const app = express();
const port = Number(process.env.PORT || 8787);
const apiKey = process.env.OPENAI_API_KEY;

if (!apiKey) {
  console.error("Missing OPENAI_API_KEY. Set it in the backend environment.");
  process.exit(1);
}

const openai = new OpenAI({ apiKey });
app.disable("x-powered-by");
app.use(helmet());
app.use(cors({
  origin: process.env.CORS_ORIGIN
    ? process.env.CORS_ORIGIN.split(",").map(s => s.trim())
    : false,
  methods: ["GET", "POST"],
  allowedHeaders: ["Content-Type", "Authorization"]
}));
app.use(express.json({ limit: "7mb", strict: true }));
app.use("/v1", rateLimit({
  windowMs: 60 * 1000,
  limit: 20,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many requests. Please wait a moment and try again." }
}));

const messageSchema = z.object({
  role: z.enum(["user", "assistant"]),
  content: z.string().trim().max(12000),
  imageDataUrl: z.string().max(6_000_000).optional()
}).strict();

const requestSchema = z.object({
  messages: z.array(messageSchema).min(1).max(30)
}).strict();

const SYSTEM_INSTRUCTIONS = `
You are KRATOS AI, a capable, friendly, precise assistant.
Help with everyday questions, mathematics, schoolwork, writing, and image understanding.
For homework, explain the method step by step and make the final answer easy to identify.
Use clear Markdown when useful. Be honest when uncertain. Do not claim to have performed actions you cannot perform.
`;

app.get("/health", (_req, res) => res.json({ ok: true, service: "kratos-ai" }));

app.post("/v1/chat", async (req, res) => {
  const parsed = requestSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid request. Check message content and image size." });
  }

  try {
    const input = parsed.data.messages.map((message) => {
      const content = [{ type: message.role === "assistant" ? "output_text" : "input_text", text: message.content }];
      if (message.role === "user" && message.imageDataUrl) {
        if (!/^data:image\/(png|jpeg|webp);base64,/i.test(message.imageDataUrl)) {
          throw new Error("Unsupported image format.");
        }
        content.push({ type: "input_image", image_url: message.imageDataUrl, detail: "auto" });
      }
      return { role: message.role, content };
    });

    const response = await openai.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6-astra",
      instructions: SYSTEM_INSTRUCTIONS,
      input,
      max_output_tokens: 1800
    });

    const reply = response.output_text?.trim();
    if (!reply) return res.status(502).json({ error: "The AI returned an empty response. Please try again." });
    return res.json({ reply });
  } catch (error) {
    console.error("KRATOS request failed:", error?.status || error?.message || "unknown error");
    const status = error?.status === 429 ? 429 : 502;
    return res.status(status).json({
      error: status === 429
        ? "AI service is busy or the account has reached a usage limit. Try again shortly."
        : "KRATOS could not complete that request. Check the backend configuration and try again."
    });
  }
});

app.use((err, _req, res, _next) => {
  if (err?.type === "entity.too.large") return res.status(413).json({ error: "Request is too large." });
  console.error("Unhandled server error:", err?.message || err);
  return res.status(500).json({ error: "Unexpected server error." });
});

app.listen(port, () => console.log(`KRATOS AI backend listening on port ${port}`));
