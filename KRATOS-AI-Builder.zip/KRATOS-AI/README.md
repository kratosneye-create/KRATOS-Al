# KRATOS AI

A native Android AI assistant starter with a premium midnight-blue interface, local chat history, voice dictation, image understanding, and a separate Node.js API server.

## Architecture

- `android/`: Kotlin + Jetpack Compose Android app.
- `backend/`: Express API. The Android app calls this server; it never contains the OpenAI API key.
- Chat history is stored locally on the device using SharedPreferences.
- Images are sent to the backend as base64 data URLs and passed to the model as image input.
- Voice input uses Android's speech-recognition intent (the device may use its configured speech provider).

## Requirements

- Android Studio Ladybug or newer
- JDK 17
- Android SDK 35
- Node.js 20+
- An OpenAI API key with API billing enabled

## 1. Start the backend

```bash
cd backend
cp .env.example .env
# Edit .env and set OPENAI_API_KEY. Never put this key in the Android project.
npm install
npm run dev
```

The server listens on port `8787` by default.

For a physical Android device, set `KRATOS_API_BASE_URL` in `android/app/build.gradle.kts` to your computer's LAN address, e.g. `http://192.168.1.20:8787/`. Your phone and computer must be on the same network. For Android emulator use `http://10.0.2.2:8787/`.

For production, deploy the backend behind HTTPS and set `KRATOS_API_BASE_URL` to the deployed HTTPS URL. Configure `CORS_ORIGIN` to the exact allowed web origin if you later add a web client. Android native clients are not governed by browser CORS, but the backend still validates requests and rate limits them.

## 2. Open the Android app

1. Open the `android/` folder in Android Studio.
2. Let Gradle sync.
3. Confirm the `KRATOS_API_BASE_URL` value in `android/app/build.gradle.kts`.
4. Run the `app` configuration on an Android 8.0+ device or emulator.

## 3. Security notes before production

- Keep `OPENAI_API_KEY` in the backend environment or a secret manager. Do not commit `.env`.
- Add user authentication (Firebase Auth, Clerk, or your own identity provider) before public deployment. The starter has request-size validation, Helmet headers, per-IP rate limiting, and strict input limits, but IP rate limiting is not user authentication.
- Use HTTPS in production.
- Configure spend limits and monitor provider usage.
- Consider storing conversations server-side only after adding authenticated user IDs and per-user authorization.
- Image payloads are size-limited and are not persisted by this backend.
- The sample backend intentionally does not expose arbitrary model names or arbitrary upstream URLs.

## API

`GET /health` — liveness check.

`POST /v1/chat`

```json
{
  "messages": [
    { "role": "user", "content": "Explain quadratic equations." },
    { "role": "assistant", "content": "..." },
    {
      "role": "user",
      "content": "What is in this picture?",
      "imageDataUrl": "data:image/jpeg;base64,..."
    }
  ]
}
```

Response:

```json
{ "reply": "..." }
```

## Notes

This is a runnable starter project, not a signed APK. Build a debug APK in Android Studio using **Build > Build Bundle(s) / APK(s) > Build APK(s)**. A real API response requires a valid backend URL and server-side API key.


## Build an APK with GitHub Actions (no Android Studio required on your phone)

This repository includes `.github/workflows/android-apk.yml`.

1. Create a GitHub repository and upload the extracted project files.
2. Open the repository's **Actions** tab.
3. Select **Build KRATOS AI APK** and choose **Run workflow** (or wait for the first push to `main`).
4. Open the completed workflow run.
5. Under **Artifacts**, download `KRATOS-AI-debug-apk`.
6. Extract the artifact and install `app-debug.apk` on your Android phone.

The workflow compiles the debug APK. It does not embed the AI API key. Configure the backend separately as described above. For a production release, create a signing key and configure signed release builds securely.
